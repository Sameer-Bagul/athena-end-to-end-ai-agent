import React from 'react';

export interface VoiceFallbackBannerProps {
  message?: string;
  onOpenSettings?: () => void;
}

export const VoiceFallbackBanner: React.FC<VoiceFallbackBannerProps> = ({
  message = '⚠️ Using basic browser speech synthesis fallback. Connect an ElevenLabs or OpenAI API key for realistic natural voice.',
  onOpenSettings,
}) => {
  return (
    <div style={{
      backgroundColor: '#FEF3C7',
      color: '#92400E',
      border: '1px solid #F59E0B',
      borderRadius: '8px',
      padding: '10px 14px',
      fontSize: '13px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      margin: '8px 0',
      boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
    }}>
      <span>{message}</span>
      {onOpenSettings && (
        <button
          onClick={onOpenSettings}
          style={{
            backgroundColor: '#D97706',
            color: '#FFFFFF',
            border: 'none',
            borderRadius: '4px',
            padding: '4px 10px',
            fontSize: '12px',
            fontWeight: 600,
            cursor: 'pointer',
            marginLeft: '12px',
            whiteSpace: 'nowrap',
          }}
        >
          Connect Provider
        </button>
      )}
    </div>
  );
};
