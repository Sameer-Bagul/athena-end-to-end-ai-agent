import { AthenaEngine, GeminiAdapter, ElevenLabsTTSAdapter } from '@athena-ai/core';

export class AthenaAgentElement extends HTMLElement {
  private engine: AthenaEngine | null = null;
  private shadow: ShadowRoot;
  private canvas: HTMLCanvasElement | null = null;

  constructor() {
    super();
    this.shadow = this.attachShadow({ mode: 'open' });
  }

  connectedCallback() {
    const avatarUrl = this.getAttribute('avatar-url') || '/models/athena.vrm';
    const apiKey = this.getAttribute('api-key') || '';
    const voiceKey = this.getAttribute('voice-key') || '';

    // Create Shadow DOM UI layout
    this.shadow.innerHTML = `
      <style>
        :host {
          display: block;
          position: fixed;
          bottom: 24px;
          right: 24px;
          z-index: 9999;
          font-family: system-ui, -apple-system, sans-serif;
        }
        .container {
          width: 340px;
          height: 500px;
          background: #0f172a;
          border-radius: 16px;
          border: 1px solid #1e293b;
          overflow: hidden;
          display: flex;
          flex-direction: column;
          box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5);
        }
        .header {
          padding: 12px;
          background: #1e293b;
          color: #f8fafc;
          font-weight: 600;
          font-size: 14px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        .warning-banner {
          background: #fef3c7;
          color: #92400e;
          font-size: 12px;
          padding: 8px 12px;
          border-bottom: 1px solid #f59e0b;
        }
        .viewport {
          flex: 1;
          position: relative;
          background: #020617;
        }
        canvas {
          width: 100%;
          height: 100%;
        }
        .controls {
          padding: 10px;
          background: #1e293b;
          display: flex;
          gap: 8px;
        }
        input {
          flex: 1;
          background: #0f172a;
          border: 1px solid #475569;
          color: #fff;
          padding: 8px;
          border-radius: 6px;
          font-size: 13px;
        }
        button {
          background: #3b82f6;
          color: #fff;
          border: none;
          padding: 8px 12px;
          border-radius: 6px;
          cursor: pointer;
          font-weight: 600;
        }
      </style>

      <div class="container">
        <div class="header">
          <span>🤖 Athena 3D Agent</span>
        </div>

        ${
          !voiceKey
            ? `<div class="warning-banner">⚠️ Browser speech fallback active. Provide voice-key for realistic ElevenLabs TTS.</div>`
            : ''
        }

        <div class="viewport">
          <canvas id="athena-canvas"></canvas>
        </div>

        <form class="controls" id="prompt-form">
          <input type="text" id="prompt-input" placeholder="Ask Athena..." />
          <button type="submit">Send</button>
        </form>
      </div>
    `;

    this.canvas = this.shadow.querySelector('#athena-canvas') as HTMLCanvasElement;
    if (this.canvas) {
      const aiProvider = new GeminiAdapter({ apiKey });
      const ttsProvider = voiceKey ? new ElevenLabsTTSAdapter({ apiKey: voiceKey }) : undefined;

      this.engine = new AthenaEngine({
        canvas: this.canvas,
        avatarUrl,
        aiProvider,
        ttsProvider,
      });

      this.engine.init(avatarUrl);
    }

    const form = this.shadow.querySelector('#prompt-form');
    const input = this.shadow.querySelector('#prompt-input') as HTMLInputElement;

    if (form && input) {
      form.addEventListener('submit', (e) => {
        e.preventDefault();
        const val = input.value.trim();
        if (val && this.engine) {
          input.value = '';
          this.engine.ask(val);
        }
      });
    }
  }

  disconnectedCallback() {
    if (this.engine) {
      this.engine.destroy();
      this.engine = null;
    }
  }
}

// Auto-register custom element if window is present
if (typeof window !== 'undefined' && !customElements.get('athena-agent')) {
  customElements.define('athena-agent', AthenaAgentElement);
}
